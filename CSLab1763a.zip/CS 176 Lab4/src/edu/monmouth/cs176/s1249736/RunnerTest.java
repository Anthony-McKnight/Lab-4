package edu.monmouth.cs176.s1249736;

public class RunnerTest {

	public static void main(String[] args) {
		RunnerList runners = new RunnerList();
		
		// 1. get total count of Registered runners. Print the value
		
		
		// 2. get total count of t-shirts for size XS, S, M, L, XL, 2XL, 3XL
		//    print individual size counts
		
		
		// 3. get sum of t-shirt sizes
		//    print to verify the count adds up value in 1. above
		
		
		// 4. Select a valid runner to delete 
		//    if found print "runner deleted" and total runners count
		//    else not found
		
		// 4a. Select a runner to delete 
		//    if found print "runner deleted" and total runners count
		//    else not found
		
		// Hint: Can we impletment a method here to do steps 4 and 4a?
		
	}

}
